<?php
/*
 * @Author: yumusb
 * @Date: 2019-08-19 17:35:15
 * @LastEditors: yumusb
 * @LastEditTime: 2019-08-19 17:50:00
 * @Description: 
 */

header("Content-type: text/html; charset=utf-8");
function exitt($a = "错误", $b = "../")
{

	echo "<script>alert('{$a}');window.location.href='{$b}'</script>";
	exit();
}
const NeedTakeNote = 'no';
//需要记录,则改为 yes
//不需要 值为 no
//如果需要记录 需要正确的数据库配置


$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url = dirname($http_type . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"]) . "/notify.php";

//echo "{$url}?check"; //访问这个输出的url检测回调可用性
$alipay_config = array(
	//签名方式,默认为RSA2(RSA2048)
	'sign_type' => "RSA2",

	//支付宝公钥
	'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAno/3T3g9A4SpYD5EDea7m0u+jevrH8qFj+nG1Cpbb5hIEsO61+e+NbcEVO0UVWeehwsKxMm7QKldcdTqaBvJ++VIplJ6o3jCmBHZg0SMwKTCMHQmgLsh9lw7lFDieBhSohz60Uhqruz7s+6jRRHXEqxzuRprISKF3yjs8YOVNeJhUvNAooIQoUzuItidGf6PzvHkJdv64AniAs8p6rRVAmqV6ROXouyna8xgY7R550wUjU/Kepn7TNtlN8yz6d104y9n4yiN4AyYWg5+SAA55YZSbLeeRWtSL8qWBD7bjf5o4wD6At3HsZWQJoHajoIm2KxR02NXKw35uDH72DaWgQIDAQAB",

	//商户私钥
	'merchant_private_key' => "MIIEpAIBAAKCAQEAzQ9kGHWqON4VlSwIVGYc30xJlGJgscdyOcHqTIm26oQSujRXya6LJcgmOQR9nfmxQBJ+7hUNBqfqYC/DIyKMTU7/WPPZp6c8JkBi6z1ICAlEfLAh4ECpPg6W/2airuex8YG7kt1jYnnBa+4PbRKCwEY4ZmU5tznjaWlnSUZuLFQdf8BVL5w7cezRuG0sdZK6rlfxKT4RZyJwagR1fW0cvDBBAFQOtB6WXalwzAGQIaZY0jdajhOxSgUNQaFFEpVJw9zZXdokNSzQsvF6qsZU4tFQpg79KQqyTA7GNtsL7uS3le7lkgMLBrtfh2FKAoigPn/d2EmcNcxSvXdvrttO4wIDAQABAoIBAQCbMDCyiiofC4QN9tr+9KCZJaTx1VoUcTqzF1x4PCjgZr+9h+uASMYp+8VhlVJ0Agnw0Y6aI/hNtzqbPMpThsvjnguFiFaKmPfegw/Zs/EVk93u92VLz+PFgUkpVMV91P9IJMSOK1oRps+JHQszorStSvdYFveNARRoLErsm465oDws81MvI4s9f8DS8weBfkBPe0sPvBaLbSvBjXva5fJCw5qkUlaDLrip6ehJqGAJiVIG21izHKHpTQCMBUjf/GzYeOi1acTK9WPF731k26cat9pR5pXZV6nkvNtvwAN717akwQNNAOnwbrzg8cnySCs6r9zVTSnEOHqBr4PelFKxAoGBAOnKnNFLtea6416Vb4pq9Bv0EFsMwx3sCLUAdAJgSN0aZgCtZZLrWtmn+kHWLbh8hfED1Abs9bm0u/aX7eE6eECnZ8s3WnJucxRGKM41G+TTBoLhdl9rUQUMQBj15BumWZC0O+tAsxL+/XLatT99pUwFJyPWDsFcRZ3dk8oSm1HNAoGBAOCKFYbfBgVDicCrSTnWpQLPfDCHFHaDXuZ/Lz22BBDYMWQyXidFt9XlAIHIrn7ORwFkDdV637GKvbKoo2pseASoRe9dlHFOLtYaCd3qUhAQ9Cmk1oOf0nS1R3cbRJJNtY5l8uXDs01dDtb3hUixsxTzL5TkOzXuxQh1groCEzNvAoGAKsWsxwXI87uBWY6RZ4uFuY9/ZokBMXo7ZZH9p2miKwFnY/xVNvnkFyoKOP1MRBJUFvISWmoD0sPkF4tYM/qUgY+fB6jK3WCjoTPsxz0kK0sIR+2j0HU7z2acW3SxFPXsMPMoezPND06jY93rhwAfu7a9oGrLLEkLW4RsQ24ACIkCgYEAo1yzVsHyPmgp08yK5RK+UTIlt6S/hY4EwIwuEabYhGzWWoCuscHugycuXD5mfgmT7XYe/n98Ok6nv1EkO6yZEUJgR0t9UYZBWzHsldECTYAYNCgijfb8hj7RtN1Y4Vy6R9TyiKn+TL30qv/Ar+fhU8+ugZQfZBjIr2PXbX9O+u8CgYB2o1EPCs6cIiWVuU1YO9BVxEsW1znOloMQ/HyXurguzER5qxJg9sQaHATVEv/h0TK2w0TWJmoJR6E+UrCtrj//iqQs+ePpGAFpIvXpiE1k+zxFeVxqWWkGBv35pp4H16MgWMt7MASdbj5SYQIEjAK1bEYSKs2u4A8zIFFi4gMNQA==",

	//编码格式
	'charset' => "UTF-8",

	//支付宝网关
	'gatewayUrl' => "https://openapi.alipay.com/gateway.do",

	//应用ID
	'app_id' => "2021002120625379",
	//最大查询重试次数
	'MaxQueryRetry' => "10",
	'notify_url' => $url,

	//查询间隔
	'QueryDuration' => "3"
);

if ($alipay_config['alipay_public_key'] == '' || $alipay_config['merchant_private_key'] == '' || $alipay_config['app_id'] == '') {
	exit("alipay_public_key/merchant_private_key/app_id must not be null");
}
/* 创建订单表。直接复制以下内容，然后选中数据库 执行就可成功创建 
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `f2f_order` (
  `id` varchar(50) NOT NULL COMMENT '订单号',
  `mark` varchar(50) NOT NULL COMMENT '备注',
  `mount` varchar(20) NOT NULL COMMENT '订单金额',
  `notify_time` varchar(20) DEFAULT NULL COMMENT '订单验证时间',
  `trade_no` varchar(30) DEFAULT NULL COMMENT '支付宝订单号',
  `buyer_logon_id` varchar(30) DEFAULT NULL COMMENT '付款账号',
  `status` varchar(10) NOT NULL COMMENT '订单状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `f2f_order` (`id`, `mark`, `mount`, `notify_time`, `trade_no`, `buyer_logon_id`, `status`) VALUES
('933a092fa70f488af8fc5e559ba840f6', '好好学习', '0.01', NULL, NULL, NULL, 'nopay');


ALTER TABLE `f2f_order`
  ADD PRIMARY KEY (`id`);
COMMIT;


*/
// $database=array(
// 	'dbname'=>'f2f',
// 	'host'=>'localhost',
// 	'port'=>3306,
// 	'user'=>'root',
// 	'pass'=>'root',
// );
//数据库配置信息。
if (NeedTakeNote == "yes") {
	$database = array(
		'dbname' => 'f2f',
		'host' => 'localhost',
		'port' => 3306,
		'user' => 'root',
		'pass' => 'root',
	);

	try {
		$db = new PDO("mysql:dbname=" . $database['dbname'] . ";host=" . $database['host'] . ";" . "port=" . $database['port'] . ";", $database['user'], $database['pass'], array(PDO::MYSQL_ATTR_INIT_COMMAND => "set names utf8"));
	} catch (PDOException $e) {
		die("数据库出错，请检查 config.php中的database配置项.<br> " . $e->getMessage() . "<br/>");
	}

	$table = 'f2f_order'; //表名字
}
